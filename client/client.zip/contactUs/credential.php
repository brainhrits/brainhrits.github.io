<?php

/**
 * @author Boomer
 * @copyright 2018
 */

define('EMAIL','');
define('PASS','');

?>